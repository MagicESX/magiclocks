Config = {} or Config

Config['usingOldESX'] = true

Config['enableNuiIndicator'] = true

Config['scriptVersion'] = 1.3

Config['admingroups'] = {
    "admin",
    "superadmin",
    "mod"
}

Config["strings"] = {
    ['open'] = "Press ~b~E~w~ to ~g~open~w~ the door",
    ['close'] = "Press ~b~E~w~ to ~r~close~w~ the door",
}
